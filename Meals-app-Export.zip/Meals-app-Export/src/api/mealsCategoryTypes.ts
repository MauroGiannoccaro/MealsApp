export interface MealCategory {
    meals: Meal[]
  }
  
  export interface Meal {
    strMeal: string
    strMealThumb: string
    idMeal: string
  }
  