import MenuAppBar from "../components/MenuAppBar"

function Header() {
  
  return (
    <MenuAppBar/>
  )
}

export default Header
